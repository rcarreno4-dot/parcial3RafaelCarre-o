package contolador; // Corrección ortográfica del paquete

import modelo.Persona;
import modelo.PersonaDAO;
import java.util.List;

public class ControladorPersona {

    private PersonaDAO dao;

    public ControladorPersona() {
        dao = new PersonaDAO();
    }

    public boolean guardar(Persona p) {
        return dao.guardar(p);
    }

    public Persona buscar(String cedula) {
        return dao.buscar(cedula);
    }

    public boolean actualizar(Persona p) {
        return dao.actualizar(p);
    }

    public boolean eliminar(String cedula) {
        return dao.eliminar(cedula);
    }

    // NUEVO: Método para obtener todas las personas de la BD
    public List<Persona> listar() {
        return dao.listar(); 
    }
}