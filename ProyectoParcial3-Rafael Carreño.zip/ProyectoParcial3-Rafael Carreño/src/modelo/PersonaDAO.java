package modelo;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList; // NUEVO
import java.util.List;      // NUEVO

public class PersonaDAO {

    // =========================================================================
    // NUEVO: MÉTODO LISTAR (Necesario para renderizar la tabla y el PDF)
    // =========================================================================
    public List<Persona> listar() {
        List<Persona> lista = new ArrayList<>();
        
        try {
            Connection con = ConexionBD.conectar();

            if (con == null) {
                return lista;
            }

            String sql = "SELECT * FROM PERSONAS";
            PreparedStatement ps = con.prepareStatement(sql);
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                Persona p = new Persona();
                p.setCedula(rs.getString("CEDULA"));
                p.setNombre(rs.getString("NOMBRE"));
                p.setApellidos(rs.getString("APELLIDOS"));
                p.setEdad(rs.getInt("EDAD"));
                p.setCorreo(rs.getString("CORREO"));
                p.setTelefono(rs.getString("TELEFONO"));
                p.setDireccion(rs.getString("DIRECCION"));
                
                lista.add(p);
            }

            rs.close();
            ps.close();
            con.close();

        } catch (Exception e) {
            e.printStackTrace();
        }

        return lista;
    }

    // =========================================================================
    // TU MÉTODO GUARDAR ORIGINAL
    // =========================================================================
    public boolean guardar(Persona p) {

        try {

            Connection con = ConexionBD.conectar();

            if(con == null){
                return false;
            }

            String sql =
            "INSERT INTO PERSONAS(CEDULA,NOMBRE,APELLIDOS,EDAD,FECHA_NACIMIENTO,CORREO,TELEFONO,DIRECCION) VALUES(?,?,?,?,?,?,?,?)";

            PreparedStatement ps =
                    con.prepareStatement(sql);

            ps.setString(1, p.getCedula());
            ps.setString(2, p.getNombre());
            ps.setString(3, p.getApellidos());
            ps.setInt(4, p.getEdad());

            ps.setDate(
                    5,
                    new java.sql.Date(
                            p.getFechaNacimiento().getTime()));

            ps.setString(6, p.getCorreo());
            ps.setString(7, p.getTelefono());
            ps.setString(8, p.getDireccion());

            ps.executeUpdate();

            con.close();

            return true;

        } catch (Exception e) {

            e.printStackTrace();
            return false;
        }
    }

    // =========================================================================
    // TU MÉTODO BUSCAR ORIGINAL
    // =========================================================================
    public Persona buscar(String cedula) {

        Persona p = null;

        try {

            Connection con = ConexionBD.conectar();

            if(con == null){
                return null;
            }

            String sql =
            "SELECT * FROM PERSONAS WHERE CEDULA=?";

            PreparedStatement ps =
                    con.prepareStatement(sql);

            ps.setString(1, cedula);

            ResultSet rs = ps.executeQuery();

            if(rs.next()) {

                p = new Persona();

                p.setCedula(rs.getString("CEDULA"));
                p.setNombre(rs.getString("NOMBRE"));
                p.setApellidos(rs.getString("APELLIDOS"));
                p.setEdad(rs.getInt("EDAD"));
                p.setCorreo(rs.getString("CORREO"));
                p.setTelefono(rs.getString("TELEFONO"));
                p.setDireccion(rs.getString("DIRECCION"));
            }

            rs.close();
            ps.close();
            con.close();

        } catch(Exception e) {

            e.printStackTrace();
        }

        return p;
    }

    // =========================================================================
    // TU MÉTODO ACTUALIZAR ORIGINAL
    // =========================================================================
    public boolean actualizar(Persona p) {

        try {

            Connection con = ConexionBD.conectar();

            if(con == null){
                return false;
            }

            String sql =
            "UPDATE PERSONAS SET NOMBRE=?,APELLIDOS=?,EDAD=?,CORREO=?,TELEFONO=?,DIRECCION=? WHERE CEDULA=?";

            PreparedStatement ps =
                    con.prepareStatement(sql);

            ps.setString(1, p.getNombre());
            ps.setString(2, p.getApellidos());
            ps.setInt(3, p.getEdad());
            ps.setString(4, p.getCorreo());
            ps.setString(5, p.getTelefono());
            ps.setString(6, p.getDireccion());
            ps.setString(7, p.getCedula());

            ps.executeUpdate();

            con.close();

            return true;

        } catch(Exception e) {

            e.printStackTrace();
            return false;
        }
    }

    // =========================================================================
    // TU MÉTODO ELIMINAR ORIGINAL
    // =========================================================================
    public boolean eliminar(String cedula) {

        try {

            Connection con = ConexionBD.conectar();

            if(con == null){
                return false;
            }

            String sql =
            "DELETE FROM PERSONAS WHERE CEDULA=?";

            PreparedStatement ps =
                    con.prepareStatement(sql);

            ps.setString(1, cedula);

            ps.executeUpdate();

            con.close();

            return true;

        } catch(Exception e) {

            e.printStackTrace();
            return false;
        }
    }
}