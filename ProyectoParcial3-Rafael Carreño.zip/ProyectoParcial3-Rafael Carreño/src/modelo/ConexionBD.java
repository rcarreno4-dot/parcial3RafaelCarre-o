package modelo;

import java.sql.Connection;
import java.sql.DriverManager;

public class ConexionBD {

    private static final String URL = "jdbc:oracle:thin:@192.168.254.215:1521:orcl";

    private static final String USER = "DatosPersonalesMVC";
    private static final String PASSWORD = "DatosPersonalesMVC";

    public static Connection conectar() {

        try {

            Class.forName("oracle.jdbc.driver.OracleDriver");

            Connection con =
                    DriverManager.getConnection(
                            URL,
                            USER,
                            PASSWORD);

            System.out.println("Conexión exitosa");

            return con;

        } catch (Exception e) {

            System.out.println("Error conexión: " + e.getMessage());

            return null;
        }
    }
}