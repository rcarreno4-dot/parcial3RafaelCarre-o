package vista;

import contolador.ControladorPersona; // Corrección ortográfica del paquete aplicada
import modelo.Persona;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.event.*;
import java.util.Date;
import java.util.List;

// Importaciones necesarias para el PDF (Requiere iText de iTextpdf.jar)
import com.itextpdf.text.Document;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfWriter;
import java.io.FileOutputStream;

public class FrmPersona extends JFrame {

    private JTextField txtCedula;
    private JTextField txtNombre;
    private JTextField txtApellidos;
    private JTextField txtEdad;
    private JTextField txtCorreo;
    private JTextField txtTelefono;
    private JTextField txtDireccion;

    private JButton btnGuardar;
    private JButton btnBuscar;
    private JButton btnEditar;
    private JButton btnEliminar;
    private JButton btnPDF;

    // COMPONENTES: Para mostrar la lista en pantalla
    private JTable tablaPersonas;
    private DefaultTableModel modeloTabla;
    private JScrollPane scrollTabla;

    // Instancia única del controlador
    private ControladorPersona cp;

    public FrmPersona() {
        cp = new ControladorPersona();

        setTitle("Proyecto Parcial 3 - Rafael Carreño");
        setSize(650, 650); // Aumentado el alto para dar espacio a la tabla
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(null);

        JLabel lblCedula = new JLabel("Cédula");
        lblCedula.setBounds(20,20,100,25);
        add(lblCedula);

        txtCedula = new JTextField();
        txtCedula.setBounds(150,20,200,25);
        add(txtCedula);

        JLabel lblNombre = new JLabel("Nombre");
        lblNombre.setBounds(20,60,100,25);
        add(lblNombre);

        txtNombre = new JTextField();
        txtNombre.setBounds(150,60,200,25);
        add(txtNombre);

        JLabel lblApellidos = new JLabel("Apellidos");
        lblApellidos.setBounds(20,100,100,25);
        add(lblApellidos);

        txtApellidos = new JTextField();
        txtApellidos.setBounds(150,100,200,25);
        add(txtApellidos);

        JLabel lblEdad = new JLabel("Edad");
        lblEdad.setBounds(20,140,100,25);
        add(lblEdad);

        txtEdad = new JTextField();
        txtEdad.setBounds(150,140,200,25);
        add(txtEdad);

        JLabel lblCorreo = new JLabel("Correo");
        lblCorreo.setBounds(20,180,100,25);
        add(lblCorreo);

        txtCorreo = new JTextField();
        txtCorreo.setBounds(150,180,250,25);
        add(txtCorreo);

        JLabel lblTelefono = new JLabel("Teléfono");
        lblTelefono.setBounds(20,220,100,25);
        add(lblTelefono);

        txtTelefono = new JTextField();
        txtTelefono.setBounds(150,220,200,25);
        add(txtTelefono);

        JLabel lblDireccion = new JLabel("Dirección");
        lblDireccion.setBounds(20,260,100,25);
        add(lblDireccion);

        txtDireccion = new JTextField();
        txtDireccion.setBounds(150,260,300,25);
        add(txtDireccion);

        btnBuscar = new JButton("Buscar");
        btnBuscar.setBounds(20,310,100,30);
        add(btnBuscar);

        btnGuardar = new JButton("Guardar");
        btnGuardar.setBounds(140,310,100,30);
        add(btnGuardar);

        btnEditar = new JButton("Editar");
        btnEditar.setBounds(260,310,100,30);
        add(btnEditar);

        btnEliminar = new JButton("Eliminar");
        btnEliminar.setBounds(380,310,100,30);
        add(btnEliminar);

        btnPDF = new JButton("PDF");
        btnPDF.setBounds(500,310,100,30);
        add(btnPDF);

        // Configuración de la Tabla Visual
        modeloTabla = new DefaultTableModel();
        modeloTabla.addColumn("Cédula");
        modeloTabla.addColumn("Nombre");
        modeloTabla.addColumn("Apellidos");
        modeloTabla.addColumn("Edad");
        modeloTabla.addColumn("Correo");

        tablaPersonas = new JTable(modeloTabla);
        scrollTabla = new JScrollPane(tablaPersonas);
        scrollTabla.setBounds(20, 360, 580, 220); // Posición debajo de los botones
        add(scrollTabla);

        // Cargar los datos en la tabla de inmediato al abrir la app
        listarPersonas();

        // Listeners
        btnGuardar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                guardarPersona();
            }
        });

        btnBuscar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                buscarPersona();
            }
        });

        btnEditar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                editarPersona();
            }
        });

        btnEliminar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                eliminarPersona();
            }
        });

        btnPDF.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                generarPDF();
            }
        });
    }

    // Método para refrescar y renderizar la tabla en pantalla
    private void listarPersonas() {
        modeloTabla.setRowCount(0); // Limpia filas viejas
        try {
            List<Persona> lista = cp.listar();
            for (Persona p : lista) {
                Object[] fila = {
                    p.getCedula(),
                    p.getNombre(),
                    p.getApellidos(),
                    p.getEdad(),
                    p.getCorreo()
                };
                modeloTabla.addRow(fila);
            }
        } catch (Exception ex) {
            System.out.println("Error al listar en tabla: " + ex.getMessage());
        }
    }

    // Lógica del botón PDF usando iText con AUTO-APERTURA
    private void generarPDF() {
        Document documento = new Document();
        String ruta = "Reporte_Personas.pdf";
        try {
            PdfWriter.getInstance(documento, new FileOutputStream(ruta));
            documento.open();

            documento.add(new Paragraph("PROYECTO PARCIAL 3 - RAFAEL CARREÑO"));
            documento.add(new Paragraph("REPORTE GENERAL DE PERSONAS REGISTRADAS"));
            documento.add(new Paragraph(" ")); // Espacio en blanco

            // Creamos una tabla en el PDF de 5 columnas
            PdfPTable tablaPDF = new PdfPTable(5);
            tablaPDF.addCell("Cédula");
            tablaPDF.addCell("Nombre");
            tablaPDF.addCell("Apellidos");
            tablaPDF.addCell("Edad");
            tablaPDF.addCell("Correo");

            List<Persona> lista = cp.listar();
            for (Persona p : lista) {
                tablaPDF.addCell(p.getCedula());
                tablaPDF.addCell(p.getNombre());
                tablaPDF.addCell(p.getApellidos());
                tablaPDF.addCell(String.valueOf(p.getEdad()));
                tablaPDF.addCell(p.getCorreo());
            }

            documento.add(tablaPDF);
            documento.close();

            JOptionPane.showMessageDialog(this, "¡PDF generado con éxito!");

            // =================================================================
            // NUEVO: Código para forzar la apertura del PDF en Windows
            // =================================================================
            try {
                java.io.File archivoPdf = new java.io.File(ruta);
                if (archivoPdf.exists()) {
                    if (java.awt.Desktop.isDesktopSupported()) {
                        java.awt.Desktop.getDesktop().open(archivoPdf);
                    } else {
                        System.out.println("Desktop no está soportado en este equipo.");
                    }
                }
            } catch (Exception ex) {
                System.out.println("Error abriendo el archivo: " + ex.getMessage());
            }
            // =================================================================

        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Error generando PDF: " + ex.getMessage());
        }
    }

    private void guardarPersona() {
        try {
            Persona p = new Persona();
            p.setCedula(txtCedula.getText());
            p.setNombre(txtNombre.getText());
            p.setApellidos(txtApellidos.getText());
            p.setEdad(Integer.parseInt(txtEdad.getText()));
            p.setFechaNacimiento(new Date());
            p.setCorreo(txtCorreo.getText());
            p.setTelefono(txtTelefono.getText());
            p.setDireccion(txtDireccion.getText());

            if(cp.guardar(p)) {
                JOptionPane.showMessageDialog(this, "Registro guardado correctamente");
                limpiarCampos();
                listarPersonas(); // Actualiza la tabla visual
            } else {
                JOptionPane.showMessageDialog(this, "Error al guardar");
            }
        } catch(Exception ex) {
            JOptionPane.showMessageDialog(this, ex.getMessage());
        }
    }

    private void buscarPersona() {
        Persona p = cp.buscar(txtCedula.getText());
        if(p != null) {
            txtNombre.setText(p.getNombre());
            txtApellidos.setText(p.getApellidos());
            txtEdad.setText(String.valueOf(p.getEdad()));
            txtCorreo.setText(p.getCorreo());
            txtTelefono.setText(p.getTelefono());
            txtDireccion.setText(p.getDireccion());
        } else {
            JOptionPane.showMessageDialog(this, "Registro no encontrado");
        }
    }

    private void editarPersona() {
        try {
            Persona p = new Persona();
            p.setCedula(txtCedula.getText());
            p.setNombre(txtNombre.getText());
            p.setApellidos(txtApellidos.getText());
            p.setEdad(Integer.parseInt(txtEdad.getText()));
            p.setCorreo(txtCorreo.getText());
            p.setTelefono(txtTelefono.getText());
            p.setDireccion(txtDireccion.getText());

            if(cp.actualizar(p)) {
                JOptionPane.showMessageDialog(this, "Registro actualizado");
                limpiarCampos();
                listarPersonas(); // Actualiza la tabla visual
            } else {
                JOptionPane.showMessageDialog(this, "Error al actualizar");
            }
        } catch(Exception ex) {
            JOptionPane.showMessageDialog(this, ex.getMessage());
        }
    }

    private void eliminarPersona() {
        if(cp.eliminar(txtCedula.getText())) {
            JOptionPane.showMessageDialog(this, "Registro eliminado");
            limpiarCampos();
            listarPersonas(); // Actualiza la tabla visual
        } else {
            JOptionPane.showMessageDialog(this, "Error al eliminar");
        }
    }

    private void limpiarCampos() {
        txtCedula.setText("");
        txtNombre.setText("");
        txtApellidos.setText("");
        txtEdad.setText("");
        txtCorreo.setText("");
        txtTelefono.setText("");
        txtDireccion.setText("");
    }
}