package proyectoparcial3.rafael.carreño;

import vista.FrmPersona;

public class ProyectoParcial3RafaelCarreño {

    public static void main(String[] args) {

        FrmPersona frm =
            new FrmPersona();

        frm.setVisible(true);
    }
}